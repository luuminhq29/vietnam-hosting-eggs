#!/usr/bin/env bash
# ==============================================================================
# Vietnam Hosting — Egg Installation Script Template
# Egg: Vietnam Hosting — openSUSE Leap (NAT Linux Container) (opensuse)
# Website: https://vietnam-hosting.net
# ==============================================================================
set -euo pipefail

SERVER_DIR="/mnt/server"
INSTALL_MARKER="${SERVER_DIR}/.vnh_installed"
mkdir -p "${SERVER_DIR}"
cd "${SERVER_DIR}"

if [[ -f "${INSTALL_MARKER}" ]]; then
    echo "[VNH][INSTALL] Reinstall detected for Vietnam Hosting — openSUSE Leap (NAT Linux Container). Preserving user data."
    VNH_REINSTALL=1
else
    echo "[VNH][INSTALL] First-time installation for Vietnam Hosting — openSUSE Leap (NAT Linux Container)."
    VNH_REINSTALL=0
fi

mkdir -p /mnt/server/.ssh/host_keys /mnt/server/.local/bin /mnt/server/scripts /mnt/server/run
chmod 700 /mnt/server/.ssh /mnt/server/.ssh/host_keys

if [[ ! -f /mnt/server/startup.sh ]]; then
    cat > /mnt/server/startup.sh <<'EOF'
#!/usr/bin/env bash
# Vietnam Hosting NAT Linux Container — User Startup Script
# Add your long-running user-space services here (runs under restart-loop protection).
set -euo pipefail
echo "[USER] Startup script initialized inside /home/container."
EOF
    chmod 755 /mnt/server/startup.sh
fi

if [[ ! -f /mnt/server/crontab ]]; then
    cat > /mnt/server/crontab <<'EOF'
# Vietnam Hosting Container User-Space Scheduled Tasks
# Syntax: <interval_seconds> <command>
# Example (commented):
# 3600 /bin/bash /home/container/scripts/example-job.sh
EOF
fi

if [[ ! -f /mnt/server/.bashrc ]]; then
    cat > /mnt/server/.bashrc <<'EOF'
export PATH="$HOME/.local/bin:$PATH"
export PS1='[\u@vietnam-hosting \W]\$ '
EOF
fi

{
    printf 'egg_id=%s\n' "opensuse"
    printf 'version=%s\n' "1.0.0"
    printf 'installed_at=%s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ 2>/dev/null || printf 'unknown')"
} > "${INSTALL_MARKER}"

echo "[VNH][INSTALL] Completed installation for Vietnam Hosting — openSUSE Leap (NAT Linux Container)."
